db_username = "willoleary6"
db_password = "sfdSDL][p-o3235-045"
db_name = "canoe"
rds_host = "canoe-not-using-aurora.crait7r8hupj.eu-west-1.rds.amazonaws.com"